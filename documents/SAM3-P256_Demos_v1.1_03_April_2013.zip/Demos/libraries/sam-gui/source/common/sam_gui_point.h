#ifndef _SAM_GUI_POINT_
#define _SAM_GUI_POINT_

#include <stdint.h>

typedef struct _SGUIPoint
{
  uint32_t dwX ;
  uint32_t dwY ;
} SGUIPoint ;

#endif // _SAM_GUI_POINT_
