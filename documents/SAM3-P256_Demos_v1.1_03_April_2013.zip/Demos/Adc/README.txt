/********************************************************
 *		SAM3-P256 ADC DEMO PROJECT
 ********************************************************/
 
IMPORTANT! In order to be able to compile the demo project you will need to download SAM3S Software pack. You can get that from Atmel's site.
 
1. Requirements
	- SAM3-P256 demo board by Olimex
	- Compatible debugger, for ex. ARM-JTAG-EW
	- IAR IDE for ARM
	- RS232 cable connected to a PC
	
2. Description

	This is a simple project that demonstrates functionality of the analogue peripherals on the board. 
	
	After powering the board it starts to periodically scan analogue inputs of the potentiometer and thermistor. You can check the current value of the voltage on the potentiomenter and the current temperature if you connect an RS232 cable to RS232_0 conector (jumpers RXD0/DRXD set to DRXD and TXD0/DTXD set to DTXD) and use the following settings 9600-8N1.
	
	Build info:
		IAR IDE v5.50
		SAM3S Software Pack v2.1 for IAR EW 5.50
				
5. Further reading
	User's manual for the SAM3-P256 board. Also feel free to consult all techincal documents released by Atmel.

6. Support
	http://www.atmel.com/
	http://www.iar.com/
	http://www.olimex.com/dev/

enjoy :)