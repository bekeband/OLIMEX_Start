/********************************************************
 *		SAM3-P256 GETTING STARTED DEMO PROJECT
 ********************************************************/
 
IMPORTANT! In order to be able to compile the demo project you will need to download SAM3S Software pack. You can get that from Atmel's site.
 
1. Requirements
	- SAM3-P256 demo board by Olimex
	- Compatible debugger, for ex. ARM-JTAG-EW
	- IAR IDE for ARM
	- RS232 cable connected to a PC
	
2. Description

	This is a simple project that demonstrates user peripherals on the board.
	
	When the board is powered the two LEDs should start blinking on the board. Pressing and release button B1 should make the yellow LED stop & restart blinking; pressing B2 should make the green LED stop & restart blinking. If you connect an RS232 cable to RS232_0 conector (jumpers RXD0/DRXD set to DRXD and TXD0/DTXD set to DTXD) and use the following settings 9600-8N1, you should see a greeting message on the terminal window.
	
	Build info:
		IAR IDE v5.50
		SAM3S Software Pack v2.1 for IAR EW 5.50
				
5. Further reading
	User's manual for the SAM3-P256 board. Also feel free to consult all techincal documents released by Atmel.

6. Support
	http://www.atmel.com/
	http://www.iar.com/
	http://www.olimex.com/dev/

enjoy :)