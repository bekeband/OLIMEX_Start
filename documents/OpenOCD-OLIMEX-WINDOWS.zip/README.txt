This is a developer version of OpenOCD 0.9.0 for Windows. It was compiled by Freddie Chopin.

This package is tested and working with Olimex OpenOCD debuggers and addapters.

This package is suitable for the following Olimex products:

1. ARM-USB-TINY - https://www.olimex.com/Products/ARM/JTAG/ARM-USB-TINY/
2. ARM-USB-TINY-H - https://www.olimex.com/Products/ARM/JTAG/ARM-USB-TINY-H/
3. ARM-USB-OCD - https://www.olimex.com/Products/ARM/JTAG/ARM-USB-OCD/
4. ARM-USB-OCD-H - https://www.olimex.com/Products/ARM/JTAG/ARM-USB-OCD-H/

5. ARM-JTAG-SWD + all of 1-4 - https://www.olimex.com/Products/ARM/JTAG/ARM-JTAG-SWD/
6. ARM-JTAG-20-10 + all of 1-5 - https://www.olimex.com/Products/ARM/JTAG/ARM-JTAG-20-10/

How to establish OpenOCD connection between the computer, the debugger, and the target for the first time:

1. Make sure the hardware connections are ok. Make sure the target and the debugger have at least one common interface (JTAG or SWD). Make sure the target is properly powered - if you want to power it from the debugger make sure that it doesn't draw more current than the debugger is able to provide. (For the testing, I used each of the products above and STM32-P107, LPC-P11C24, and EM-32G880F128-H as targets. The debugger-target setup was powered by a personal computer via USB-A-B-CABLE).

2. Extract the archive. (I right-clicked over it and selected "Extract here")

3. Open command prompt. (I clicked "Start" button and wrote "cmd.exe". Then I pressed the enter key)

4. Navigate to either folder "bin" or "bin-x64" using "cd <path name>", depending on whether you have 32-bit Windows or 64-bit Windows installed.  (I wrote "cd C:\Users\XXXX\Desktop\openocd-0.9.0-dev\bin-x64" since I use 64-bit Windows and I extracted the archive at the Windows desktop)

5. Use one of the commands below. If you use 32-bit Windows replace "openocd-x64-0.9.0-dev.exe" with "openocd-0.9.0-dev.exe". The "stm32f1x.cfg" is a sample configuration file for STM32-P107 - if your target is different replace the name of the .cfg with the one suitalbe for your target. All available .cfg files are located in folder "scripts\target".

Example simple connection commands for the different hardware options:

5.1. ARM-USB-TINY

openocd-x64-0.9.0-dev.exe -f ./interface/ftdi/olimex-arm-usb-tiny.cfg -f ./target/stm32f1x.cfg

5.2. ARM-USB-TINY-H

openocd-x64-0.9.0-dev.exe -f ./interface/ftdi/olimex-arm-usb-tiny-h.cfg -f ./target/stm32f1x.cfg

5.3. ARM-USB-OCD

openocd-x64-0.9.0-dev.exe -f ./interface/ftdi/olimex-arm-usb-ocd.cfg -f ./target/stm32f1x.cfg

5.4. ARM-USB-OCD-H

openocd-x64-0.9.0-dev.exe -f ./interface/ftdi/olimex-arm-usb-ocd-h.cfg -f ./target/stm32f1x.cfg

5.5. ARM-JTAG-SWD + all of 1-4

After the parameter specifying the debugger add "-f interface/ftdi/olimex-arm-jtag-swd.cfg"

openocd-x64-0.9.0-dev.exe -f interface/ftdi/olimex-arm-usb-x<-x>.cfg -f interface/ftdi/olimex-arm-jtag-swd.cfg -f target/stm32f1x.cfg

For ARM-USB-OCD-H it would be:

openocd-x64-0.9.0-dev.exe -f interface/ftdi/olimex-arm-usb-ocd-h.cfg -f interface/ftdi/olimex-arm-jtag-swd.cfg -f target/stm32f1x.cfg

5.6. ARM-JTAG-20-10 + all of 1-5

Does not require anything extra. Use the connection line for the debugger (and the SWD adapter if such was used).

6. If the connection is successful you would be listed the available hardware breakpoints of your target and the GDB connections to the target would be possible.

7. At this point you can choose how to access the GDB server at port 4444. You can establish telnet connection at port 4444 and send commands directly; or you can use IAR for ARM (remember to configure the GDB settings in the project options).

I opened a telnet connection in PuTTY to localhost at port 4444. Then I wrote "halt" which halted the exacuting of the program loaded on the target.

For more information about the commands refer to the "OpenOCD User�s Guide.pdf" inside the main folder of the archive.

For more information about the Olimex products refer to the user's manual of each of the products.