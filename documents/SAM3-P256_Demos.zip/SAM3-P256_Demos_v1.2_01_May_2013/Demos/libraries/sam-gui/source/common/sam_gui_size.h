#ifndef _SAM_GUI_SIZE_
#define _SAM_GUI_SIZE_

#include "libsam_gui.h"

typedef struct _SGUISize
{
    uint32_t dwWidth ;
    uint32_t dwHeight ;
} SGUISize ;

#endif // _SAM_GUI_SIZE_
