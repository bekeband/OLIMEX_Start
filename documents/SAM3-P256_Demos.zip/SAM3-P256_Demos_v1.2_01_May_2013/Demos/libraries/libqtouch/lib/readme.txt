Change the name for different project:

libsam3s-32qt-k-8rs-gnu.a is rename (copy) to libqtouch_sam3s_gcc_rel.a

libsam3s-32qt-k-8rs-iar.a is rename (copy) to libqtouch_sam3s_ewarm_rel.a

