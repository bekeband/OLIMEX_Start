/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2005
 *
 *    File name   : ntc.h
 *    Description : NTC module include file
 *
 *    History :
 *    1. Date        : July 28, 2005
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 33388 $
 **************************************************************************/
#ifndef  __NTC_H
#define  __NTC_H

#include <math.h>

typedef float Flo32;
typedef double Flo64;

Flo32 NtcRatioToTemperature (Flo32 Ratio);
Flo32 NtcTemperatureToRatio (Flo32 Ratio);

#endif  /* __NTC_H */
